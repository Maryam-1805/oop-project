#include <iostream>
using namespace std;

class My_Class 
{
    static int count; // Static data member

public:
	My_Class() 
	{
    count++; // Increment count when an object is created
     }

    // Static member function
    static void show() {
        cout << "Total lecture in one day: " <<count<<endl;
    }
};

int My_Class::count = 0; // Initializing static data member 
int main()

{
	My_Class lec1;
	My_Class lec2;
	My_Class lec3;
	My_Class lec4;
	My_Class lec5;
	
	My_Class::show();
}
