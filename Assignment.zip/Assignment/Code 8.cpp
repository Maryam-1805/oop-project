#include <iostream>
using namespace std;

class Complex
{
    int a, b;

public:
    void Set_data(int x, int y)
    {
        a = x;
        b = y;
    }
      // Friend function
    friend Complex Addcomplex(Complex c1, Complex c2);
    void Get_data()
    {
        cout << " Complex Number = " << a << " + " << b << "i" << '\n';
    }
};
// Friend function definition
Complex Addcomplex(Complex c1, Complex c2)
{
    Complex c3;
    c3.Set_data((c1.a + c2.a), (c1.b + c2.b));
    return c3;
}

int main()
{
    Complex com1, com2, sum;
    com1.Set_data(7, 1);       // complex nmbr 7+1i
    com1.Get_data();

    com2.Set_data(3, 9);      //complex number
    com2.Get_data();

// Adding two complex numbers
    sum = Addcomplex(com1, com2);
    sum.Get_data();

    return 0;
}
