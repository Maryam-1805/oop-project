#include<iostream>
using namespace std;
int Max(int a , int b ,  int c)
{
	if(a>b & a>c)
	{
		cout<<"Maximum number is:"<<endl;
	}
	else if(b>a & b>c)
	{
		cout<<"Maximum number is:"<<endl;
	}
	else
	{
		cout<<"Maximum number is:"<<endl;
	}
}
string Max(string a , string b ,  string c)
{
	if(a>b & a>c)
	{
		cout<<"Maximum name is:"<<endl;
	}
	else if(b>a & b>c)
	{
		cout<<"Maximum name is:"<<endl;
	}
	else
	{
		cout<<"Maximum name is:"<<endl;
	}
}
int main()
{
	int a,b,c;
	cout<<"Enter three Number:"<<endl;
	cin>>a>>b>>c;
	cout<<Max(a,b,c)<<endl;
	
	string a,b,c;
	cout<<"Enter three Name:"<<endl;
	cin>>a;
	cin>>b;
	cin>>c;
	cout<<Max(a,b,c)<<endl;
}


