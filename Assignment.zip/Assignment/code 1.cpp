#include<iostream>
using namespace std;
void sortNmbr(int& x , int& y);
int main()
{
	int a,b;
	cout<<"Enter first digit :"<<endl;
	cin>>a;
	cout<<"Enter second digit :"<<endl;
	cin>>b;
	
	sortNmbr(a , b);
	
	cout<<"Sorted Number :"<< a << " " << b << endl;
	return 0;
}
void sortNmbr(int& x , int& y)
{
	//sorting number if decending numbr
if(x>y)
{
	int tem;
	tem = y;
	y = x;
	x = tem;
}
}

