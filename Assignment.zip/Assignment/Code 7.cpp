#include<iostream>
using namespace std;
class Distance 
{
	int feet;
    float inches;
public:
    //function to  input distance
    void inputDistance() {
        cout << "Enter feet: ";
        cin >> feet;
        cout << "Enter inches: ";
        cin >> inches;
    }
    //function to output distance
    void outputDistance()  {
    cout << "Feet: " << feet << " Inches: " << inches << endl;
    }
    //add two distance objects
    Distance add( Distance dis) 
	 {
       Distance rslt;
       rslt.feet = feet + dis.feet;
       rslt.inches = inches + dis.inches;
       
       if(rslt.inches >= 12.0)
    {
    	rslt.inches -=12;
    	rslt.feet++;
	}
	return rslt;
     }
};

int main()
{
	Distance dstnc1 , dstnc2 , sum;
	
	cout<<"Enter the first distance : "<<endl;
	dstnc1.inputDistance();
	
	cout<<"Enter scnd Distance : "<<endl;
	dstnc2.inputDistance();
	
	// Now adding 
	sum = dstnc1.add(dstnc2);
	// Displaying the result
   cout << "Sum of distances:" <<endl;
   sum.outputDistance();
   return 0;
}

