#include<iostream>
using namespace std;
float Pie(float,float pi = 3.14);
int main()
{
	float r , area;
	cout<<"Enter radius ="<<endl;
	cin>>r;
	area=Pie(r);
cout<<"Area of circle is "<<area;
}

float Pie(float r , float pi)
{
	float ara;
	ara = pi*r*r;
	return(ara);
}
