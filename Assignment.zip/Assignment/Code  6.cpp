#include<iostream>
using namespace std;
class Item
{
	int nmbr;
	double cost;
	public:
		void show_data()
		{
	cout<<"Number : "<<nmbr<<endl;
	cout<<"cost : "<<cost<<endl;	
		}
		// declaration of get_data() outside the class
		friend void get_data(Item & item);
};

// Definition of get_data() outside the class
void get_data(Item & item)
{
	cout<<"Enter item number : "<<endl;
	cin>>item.nmbr;
	
	cout<<"Enter item cost : "<<endl;
	cin>>item.cost;
	
}

int main()
{
	Item item;
	get_data(item);
	item.show_data();
}
