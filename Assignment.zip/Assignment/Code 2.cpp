#include<iostream>
using namespace std;
inline int Multiply(int a , int b)
{
	return(a*b);
}
int main()
{
	cout<<"Multiply(11,33) : "<<Multiply(11 , 33)<<endl;
	cout<<"Multiply(10,20) : "<<Multiply(10 , 20)<<endl;
}
