#include <iostream>
using namespace std;

class EMPLOYEE {

    int EMPCODE;
    string EMPNAME;
public:
	//function to input data
    void get_data() {
        cout << "Enter employee code here: "<<endl;
        cin >> EMPCODE;
        cout << "Enter employee name here: "<<endl;
        cin >> EMPNAME;
    }
    //function to display data
    void show() 
	{
        cout << "Employee Code: " << EMPCODE << endl;
        cout << "Employee Name: " << EMPNAME << endl;
    }
};
int main()
{
	const int num_employees = 6;
    EMPLOYEE
    employees[num_employees];
    
    for(int x=0; x < num_employees; x++)
    {
    	cout<<"Enter details for employee "<<x + 1<<":"<< endl;
    	employees[x].get_data();
	}
	cout<<"Employees Details : "<<endl;
	
	for(int x=0; x < num_employees; x++)
	{
		employees[x].show();
	}
}
