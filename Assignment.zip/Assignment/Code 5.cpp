#include<iostream>
using namespace std;
class Emloyee
{
	
int id;
string name;
int age;
string gender;
public:
	void get()
	{
	cout<<"Enter your id:" <<endl;
	cin>>id;
	cout<<"Enter your Name:" <<endl;
	cin>>name;
	cout<<"Enter your age:" <<endl;
	cin>>age;
	cout<<"Enter your gender:" <<endl;
	cin>>gender;
}
	public:
void show()
	{
		cout<<"Your id:"<<id<<endl;
cout<<"Your Name:"<<name <<endl;
	cout<<"Your age:"<<age <<endl;
cout<<"Your Gender:"<<gender<<endl;
	}

};
int main()
{
	Emloyee emp;
	emp.get();
	emp.show();
	
}
